exports.sysDateTime = function getDateTime(){
    return new Date();
}