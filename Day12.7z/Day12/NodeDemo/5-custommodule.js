var http=require('http');
var datetime=require('./dateutility');
var counter=0;
var server = http.createServer(function(req,res){
res.writeHead(200,{'Content-Type':'application/json'});
counter = counter+1;
data ={"Time":datetime.sysDateTime(),"You are visitor no ":counter};
res.write(JSON.stringify(data));
res.end();
});
 
server.listen(8080,function(){
    console.log('server started');
})