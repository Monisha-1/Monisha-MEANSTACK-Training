console.log('My script');
document.getElementById("hid").innerHTML="Welcome to java script";
document.getElementById("hid").style.color='blue';
 
function changeMe(){
    document.getElementById("hid").style.backgroundColor='tomato';
}