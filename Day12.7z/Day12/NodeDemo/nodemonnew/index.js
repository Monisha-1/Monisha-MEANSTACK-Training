var caseutility=require('upper-case')
output =caseutility.upperCase('Training Started');
console.log(output);