varhttp = require('http');
varurl = require('url');
http.createServer(function (req, res) {​​​​​​​​
res.writeHead(200, {​​​​​​​​'Content-Type':'text/plain'}​​​​​​​​);
console.log('request url',req.url); //nodedemo?name=raghu&city=bengaluru
varq = url.parse(req.url, true);
console.log(q.host); //returns 'localhost:8080'
console.log(q.pathname); //returns '/nodedemo'
console.log(q.search); //returns '?name=raghu&city=bengaluru'
 
varqdata = q.query; //returns an object: {​​​​​​​​ name: 'raghu', city: 'benaluru' }​​​​​​​​
console.log('query as an object' ,qdata);
console.log(qdata.city); //returns 'city'
console.log(qdata.name); //returns 'name'
res.end('url demo');
}​​​​​​​​).listen(8080,function(){​​​​​​​​
console.log('server is running');
}​​​​​​​​);

