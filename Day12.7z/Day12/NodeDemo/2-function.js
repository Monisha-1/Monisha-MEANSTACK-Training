var welcome = function (){
    console.log('welcome to node');
   }

   welcome();
   