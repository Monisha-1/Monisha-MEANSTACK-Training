var fs = require('fs')
fs.readFile('news.txt',function(err,data){
    if (err)
        console.log('error while reading a file');
    console.log(data);
    res.write(JSON.stringify(data));
res.end();
});
 
function greet(){
    console.log('greet');
}
greet();